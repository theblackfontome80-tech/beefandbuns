# Beef & Buns — Sousse · Site officiel

Site vitrine premium, statique, sans étape de build. Prêt à déployer sur Netlify, Vercel, GitHub Pages, OVH, ou tout hébergement statique.

## Structure

```
index.html            Page unique : Hero · Menu · Signature · Restaurant · Galerie · Contact
404.html              Page d'erreur
assets/css/main.css   Design system (tokens couleurs/typo), composants, responsive
assets/js/content.js  ← TOUT le contenu éditable : infos, menu, prix, galerie, photos
assets/js/app.js      Composants : header sticky, menu mobile, onglets du menu, galerie,
                      carte, animations au scroll, parallaxe, bouton retour en haut
assets/img/           Dossier prévu pour les photos officielles
robots.txt · sitemap.xml · site.webmanifest · assets/favicon.svg
```

## Sources des données

| Donnée | Source |
|---|---|
| Produits, compositions, prix | Menu officiel « menu Beef & Buns A4v.pdf » (lien dans la bio Instagram) |
| Horaires 12:00 – 01:00 | Bio Instagram — **à confirmer** (jours d'ouverture non précisés) |
| Adresse, téléphone | Fournis par le restaurant ; téléphone confirmé sur le menu |
| Coordonnées GPS | Lien Google Maps officiel |

## À compléter avant la mise en ligne

1. **Photos** :
   - Déjà officielles (Instagram, `assets/img/gallery/`) : galerie complète, section Signature
     (anatomie de l'OG Smash), section Restaurant (salle), carte OG Chicken du menu.
     Ce sont des miniatures de 640 px de haut : pour une netteté maximale, remplacez-les par les
     originaux HD en gardant les mêmes noms de fichiers.
   - Encore temporaires (Unsplash) : hero, autres cartes du menu, slider Signature, image Open Graph.
   - Slider Signature (`SIGNATURE` dans `content.js`) : l'idéal est une photo **détourée**
     (PNG/WebP transparent, ~1200 px) de chaque burger ; le masque radial actuel fond la photo dans la scène.
     Remplacez les champs `image` dans `assets/js/content.js` (ex. `"assets/img/menu/og-smash.webp"`)
     et les `TODO` dans `index.html`.
2. **Domaine** : remplacer `https://www.beefandbuns.tn/` (canonical, Open Graph, JSON-LD,
   `robots.txt`, `sitemap.xml`) par le domaine définitif.
3. **Horaires** : confirmer avec le restaurant (`hours` dans `content.js` + `openingHoursSpecification` dans `index.html`).
4. **Menu enfants** : le menu officiel ne nomme pas les burgers n°10 et n°11 ; ils sont affichés
   « Kids N°10 — Beef » et « Kids N°11 — Chicken ».

## Modifier le menu

Tout se fait dans `assets/js/content.js` → `MENU.categories`. Chaque produit :

```js
{ name: "OG Smash", price: 22.7, image: "assets/img/menu/og-smash.webp",
  desc: ["Brioche potato bun", "2x smashed beef", "..."], tag: "Signature" }
```

Prix inconnu → `price: null` (affiche « — »). Ajouter une catégorie = ajouter un objet `{ id, label, intro, items }`.

## Lancer en local

```
npx http-server -c-1 .
```

## Qualité

- SEO local : title/description ciblés Sousse, balises géo, JSON-LD `Restaurant` (adresse, GPS, horaires, téléphone), sitemap.
- Open Graph + Twitter Cards.
- Accessibilité : lien d'évitement, onglets ARIA navigables au clavier (flèches / Home / End), focus visibles,
  menu mobile avec `inert` + Échap, `prefers-reduced-motion` respecté, textes alternatifs.
- Performance : aucune librairie JS, image hero préchargée, images responsives (`srcset`) et lazy-load,
  carte Google chargée seulement à l'approche, rendu du menu à la demande par onglet.

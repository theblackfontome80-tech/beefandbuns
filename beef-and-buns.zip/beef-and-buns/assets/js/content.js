/* ==========================================================================
   BEEF & BUNS — CONTENU DU SITE
   --------------------------------------------------------------------------
   Toutes les données éditables du site sont ici : infos pratiques, menu,
   galerie. Modifier ce fichier suffit pour mettre à jour le site.

   SOURCES
   - Menu, descriptions et prix : menu officiel « menu Beef & Buns A4v.pdf »
     (lien Google Drive publié dans la bio Instagram @beef.and.buns.sousse).
   - Horaires : bio Instagram (« 🕞 12h - 01h »).
   - Adresse / téléphone : fournis par le restaurant (téléphone confirmé
     sur le menu officiel : 28 15 15 03).

   PHOTOS
   Les photos actuelles sont des visuels temporaires haute qualité
   (Unsplash). Remplacez chaque champ `image` par le chemin d'une photo
   officielle, par ex. "assets/img/menu/og-smash.webp".
   Les champs marqués `null` = information non disponible → à compléter.
   ========================================================================== */

(function () {
  "use strict";

  /** Construit une URL d'image optimisée (Unsplash) ou renvoie le chemin local. */
  function img(src, w, h) {
    if (!src) return "";
    if (!src.startsWith("photo-")) return src; // image locale / officielle
    var url = "https://images.unsplash.com/" + src + "?auto=format&fit=crop&q=72&w=" + w;
    return h ? url + "&h=" + h : url;
  }

  /* Banque de visuels temporaires — à remplacer par les photos officielles */
  var PHOTO = {
    smashHero: "photo-1568901346375-23c9450c58cd",
    burgerDark: "photo-1550547660-d9450f859349",
    burgerBoard: "photo-1571091718767-18b5b1457add",
    burgerStack: "photo-1553979459-d2229ba7433b",
    burgerHand: "photo-1586190848861-99aa4a171e90",
    burgerCheese: "photo-1572802419224-296b0aeee0d9",
    burgerFries: "photo-1565299507177-b0ac66763828",
    burgerClassic: "photo-1551782450-a2132b4ba21d",
    chicken: "photo-1606755962773-d324e0a13086",
    tenders: "photo-1562967914-608f82629710",
    fries: "photo-1573080496219-bb080dd4f877",
    soda: "photo-1622483767028-3f66f32aef97",
    water: "photo-1548839140-29a749e1cf4d",
    interior: "photo-1517248135467-4c7edcad34c4",
    interior2: "photo-1555396273-367ea4eb4db5",

    /* Photos officielles — Instagram @beef.and.buns.sousse (miniatures 640 px).
       Pour une meilleure netteté, remplacez-les par les originaux en haute définition. */
    igInteriorGuests: "assets/img/gallery/interior-guests.jpg",
    igInteriorRed: "assets/img/gallery/interior-red.jpg",
    igSmashAnatomy: "assets/img/gallery/smash-anatomy.jpg",
    igOgChicken: "assets/img/gallery/og-chicken.jpg",
    igBagsCar: "assets/img/gallery/bags-car.jpg",
    igBagsIllustration: "assets/img/gallery/bags-illustration.jpg",
    igNeverFrozen: "assets/img/gallery/never-frozen.jpg",
    igTorchi: "assets/img/gallery/torchi-finalists.jpg"
  };

  var SITE = {
    name: "Beef & Buns",
    city: "Sousse",
    tagline: "Not just a burger. An experience.",
    slogan: "Simple. Bold. Perfect.",
    phoneDisplay: "+216 28 151 503",
    phoneHref: "tel:+21628151503",
    address: {
      street: "Avenue Les Orangers",
      postalCode: "4051",
      city: "Sousse",
      country: "Tunisia"
    },
    geo: { lat: 35.8578414, lng: 10.6078741 },
    hours: "12:00 — 01:00",
    // Horaires issus de la bio Instagram — à confirmer avec le restaurant.
    hoursNote: "As listed on our Instagram — hours may vary.",
    instagram: "https://www.instagram.com/beef.and.buns.sousse/",
    instagramHandle: "@beef.and.buns.sousse",
    mapsShare: "https://maps.app.goo.gl/fgT86Mf6YwQRnjHaA",
    currency: "TND"
  };

  SITE.mapsEmbed =
    "https://www.google.com/maps?q=" + SITE.geo.lat + "," + SITE.geo.lng + "&z=16&output=embed";
  SITE.directions =
    "https://www.google.com/maps/dir/?api=1&destination=" + SITE.geo.lat + "," + SITE.geo.lng;

  /* --------------------------------------------------------------------------
     MENU — produits et prix réels (menu officiel)
     Pour ajouter une catégorie (ex. « Beef Burgers »), ajoutez un objet
     dans `categories` avec un `id` unique et une liste `items`.
     -------------------------------------------------------------------------- */
  var MENU = {
    note: "Unlimited fries with every burger",
    categories: [
      {
        id: "smash",
        label: "Smash Burgers",
        intro: "Double smashed beef on a brioche potato bun. The house signature.",
        items: [
          { no: 1, name: "OG Smash", price: 22.7, image: PHOTO.smashHero,
            desc: ["Brioche potato bun", "2x smashed beef", "2x American cheese", "OG sauce", "Pickles", "Caramelized onions"] },
          { no: 2, name: "OG Smash Oklahoma", price: 22.7, image: PHOTO.burgerHand,
            desc: ["Brioche potato bun", "2x smashed beef", "2x American cheese", "OG sauce", "Pickles", "Grilled onions smashed into the beef"] },
          { no: 3, name: "Truffle Mushroom", price: 29.5, image: PHOTO.burgerBoard, tag: "Signature",
            desc: ["Brioche potato bun", "2x smashed beef", "2x smoked cheese", "Truffle mayo", "Grilled mushrooms", "Crispy onions", "Fresh rocket"] },
          { no: 4, name: "Hot Smash", price: 25, image: PHOTO.burgerCheese, tag: "Spicy",
            desc: ["Brioche potato bun", "2x smashed beef", "2x American cheese", "OG sauce", "Crispy onions", "Jalapeños", "Topped with hot sauce"] },
          { no: 8, name: "OG Triple", price: 27.5, image: PHOTO.burgerDark,
            desc: ["Brioche potato bun", "Triple smashed beef", "Triple American cheese", "OG sauce", "Caramelised onions", "Pickles"] },
          { no: 9, name: "OG Bacon", price: 27.5, image: PHOTO.burgerStack,
            desc: ["Brioche potato bun", "2x smashed beef", "2x American cheese", "OG sauce", "Caramelized onions", "Bacon", "Fresh rocket", "Egg"] }
        ]
      },
      {
        id: "chicken",
        label: "Chicken Burgers",
        intro: "Crispy chicken, brioche potato bun, OG sauce.",
        items: [
          { no: 5, name: "OG Chicken", price: 17.5, image: PHOTO.igOgChicken,
            desc: ["Brioche potato bun", "Crispy chicken", "American cheese", "OG sauce", "Coleslaw"] },
          { no: 6, name: "Classic Chicken", price: 17.5, image: PHOTO.burgerClassic,
            desc: ["Brioche potato bun", "Crispy chicken", "American cheese", "OG sauce", "Lettuce", "Tomato", "Onions"] },
          { no: 7, name: "Hot Chicken", price: 20, image: PHOTO.burgerFries, tag: "Spicy",
            desc: ["Brioche potato bun", "Crispy chicken", "Smoked cheese", "OG sauce", "Caramelized onions", "Jalapeños", "Topped with hot sauce"] }
        ]
      },
      {
        id: "sides",
        label: "Sides",
        intro: "Crispy chicken tenders and classic fries.",
        items: [
          { name: "Crispy Chicken Tenders — 2 pieces", price: 6, image: PHOTO.tenders,
            desc: ["2x crispy chicken tenders"] },
          { name: "Crispy Chicken Tenders — 4 pieces", price: 12, image: PHOTO.tenders,
            desc: ["4x chicken tenders", "Coleslaw"] },
          { name: "Crispy Chicken Tenders — 8 pieces", price: 22, image: PHOTO.tenders,
            desc: ["8x chicken tenders", "Coleslaw"] },
          { name: "Classic Fries", price: 3, image: PHOTO.fries,
            desc: ["Classic fries — unlimited with every burger"] }
        ]
      },
      {
        id: "kids",
        label: "Kids",
        intro: "Beef & Buns Kids — the same recipe, in a smaller size.",
        items: [
          { no: 10, name: "Kids N°10 — Beef", price: 15, image: PHOTO.burgerClassic,
            desc: ["Brioche potato bun", "1x smashed beef", "1x American cheese", "OG sauce", "Lettuce", "Tomato", "Onions"] },
          { no: 11, name: "Kids N°11 — Chicken", price: 12.5, image: PHOTO.chicken,
            desc: ["Brioche potato bun", "Crispy chicken", "American cheese", "OG sauce", "Lettuce", "Tomato", "Onions"] }
        ]
      },
      {
        id: "drinks",
        label: "Drinks",
        intro: "Cold drinks to go with your burger.",
        items: [
          { name: "Sodas", price: 3, image: PHOTO.soda, desc: ["Selection of soft drinks"] },
          { name: "Water 0.5 L", price: 1.5, image: PHOTO.water, desc: ["Still water, 0.5 L"] },
          { name: "Water 1 L", price: 3, image: PHOTO.water, desc: ["Still water, 1 L"] }
        ]
      }
    ],
    extras: [
      { name: "American cheese", price: 3 },
      { name: "Smoked cheese", price: 3 },
      { name: "Bacon", price: 5 },
      { name: "Pastrami", price: 5 },
      { name: "Smashed beef", price: 6 },
      { name: "Pickles", price: 2 },
      { name: "Jalapeños", price: 2.5 },
      { name: "Grilled mushrooms", price: 3 },
      { name: "Hot sauce", price: 3.5 },
      { name: "OG sauce", price: 2.5 },
      { name: "Truffle mayo", price: 3 },
      { name: "Heinz Mayonnaise", price: 2.5 },
      { name: "Heinz Ketchup", price: 2.5 },
      { name: "Fresh rocket", price: 2.5 }
    ]
  };

  /* --------------------------------------------------------------------------
     GALERIE — photos officielles du compte Instagram @beef.and.buns.sousse.
     Grille « masonry » : les images gardent leur format d'origine.
     `w`/`h` : dimensions du fichier (évite les sauts de mise en page).
     `href` : lien vers la publication Instagram.
     -------------------------------------------------------------------------- */
  var IG = "https://www.instagram.com/beef.and.buns.sousse/";
  var GALLERY = [
    { image: PHOTO.igInteriorRed, w: 360, h: 640, alt: "Inside Beef & Buns Sousse: red chairs and a guest with a burger bag", href: IG + "reel/DfU8bF7PHe3/" },
    { image: PHOTO.igSmashAnatomy, w: 480, h: 640, alt: "Anatomy of the OG Smash: brioche bun, OG sauce, pickles, caramelised onions, American cheese and two smash beef patties", href: IG + "p/DcjaLW1iF2Y/" },
    { image: PHOTO.igOgChicken, w: 486, h: 640, alt: "The OG Chicken burger with coleslaw", href: IG + "p/DgA6ZctIp1q/" },
    { image: PHOTO.igBagsCar, w: 520, h: 640, alt: "A stack of red Beef & Buns bags on a car seat — flavour, en route", href: IG + "p/Dfjw4deCIRc/" },
    { image: PHOTO.igNeverFrozen, w: 360, h: 640, alt: "Fresh ground beef — never frozen", href: IG + "reel/DfW-n46oxxj/" },
    { image: PHOTO.igInteriorGuests, w: 480, h: 640, alt: "Guests sharing burgers in the Beef & Buns dining room", href: IG + "p/DbnmKM4iIHe/" },
    { image: PHOTO.igTorchi, w: 516, h: 640, alt: "Beef & Buns named finalist at the Torchi Awards, burger category", href: IG + "p/Df4XZ5NooOg/" },
    { image: PHOTO.igBagsIllustration, w: 360, h: 640, alt: "Illustration of two friends carrying Beef & Buns bags", href: IG + "reel/Df67tAHPxdr/" }
  ];

  /* --------------------------------------------------------------------------
     SLIDER SIGNATURE — burgers mis en avant dans la section « Signature ».
     `item`  : nom exact du produit dans MENU (prix et composition repris du menu)
     `word`  : grand mot animé derrière le burger
     `image` : idéalement une photo détourée (PNG/WebP transparent) du burger
     `tone`  : [fond, lueur] de la scène
     `bits`  : ingrédients animés autour du burger
       (sesame, pickle, onion, cheese, jalapeno, chili, mushroom, leaf, bacon)
     -------------------------------------------------------------------------- */
  var SIGNATURE = [
    { item: "OG Smash", word: "Smash", image: PHOTO.smashHero, tone: ["#21160d", "#7d5129"],
      bits: ["sesame", "pickle", "onion", "cheese", "sesame", "pickle", "onion", "sesame"] },
    { item: "Truffle Mushroom", word: "Truffle", image: PHOTO.burgerBoard, tone: ["#19170f", "#5a4e30"],
      bits: ["mushroom", "leaf", "onion", "mushroom", "sesame", "leaf", "mushroom", "sesame"] },
    { item: "Hot Smash", word: "Hot", image: PHOTO.burgerCheese, tone: ["#220c09", "#7a2316"],
      bits: ["jalapeno", "chili", "cheese", "jalapeno", "onion", "chili", "jalapeno", "chili"] },
    { item: "OG Bacon", word: "Bacon", image: PHOTO.burgerHand, tone: ["#1e110b", "#6b3520"],
      bits: ["bacon", "leaf", "cheese", "bacon", "sesame", "onion", "bacon", "leaf"] },
    { item: "OG Triple", word: "Triple", image: PHOTO.burgerStack, tone: ["#141210", "#4d3c2b"],
      bits: ["cheese", "pickle", "onion", "cheese", "sesame", "pickle", "cheese", "onion"] }
  ];

  window.BB = { SITE: SITE, MENU: MENU, GALLERY: GALLERY, SIGNATURE: SIGNATURE, PHOTO: PHOTO, img: img };
})();

/* ==========================================================================
   BEEF & BUNS — Application
   Composants : Header · MobileMenu · Menu (tabs) · Signature · Gallery ·
                Map · Reveal · Parallax · BackToTop
   ========================================================================== */
(function () {
  "use strict";

  var BB = window.BB;
  if (!BB) return;
  var SITE = BB.SITE, MENU = BB.MENU, GALLERY = BB.GALLERY, PHOTO = BB.PHOTO, img = BB.img;

  var $ = function (s, c) { return (c || document).querySelector(s); };
  var $$ = function (s, c) { return Array.prototype.slice.call((c || document).querySelectorAll(s)); };
  var reduceMotion = window.matchMedia("(prefers-reduced-motion: reduce)").matches;

  /* ---------- Helpers ---------- */
  function esc(str) {
    return String(str).replace(/[&<>"']/g, function (c) {
      return { "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[c];
    });
  }
  function price(p) {
    if (p === null || p === undefined) return '<span class="card__price">— <small>' + SITE.currency + "</small></span>";
    return '<span class="card__price">' + p + "<small>" + SITE.currency + "</small></span>";
  }
  function pad(n) { return n < 10 ? "0" + n : String(n); }
  function srcset(id, widths, ratio) {
    return widths.map(function (w) {
      return img(id, w, ratio ? Math.round(w * ratio) : 0) + " " + w + "w";
    }).join(", ");
  }
  function picture(id, opts) {
    opts = opts || {};
    var widths = opts.widths || [480, 800, 1200];
    var ratio = opts.ratio || 0;
    var isRemote = id && id.indexOf("photo-") === 0;
    return '<img src="' + img(id, widths[1] || widths[0], ratio ? Math.round((widths[1] || widths[0]) * ratio) : 0) + '"' +
      (isRemote ? ' srcset="' + srcset(id, widths, ratio) + '" sizes="' + (opts.sizes || "100vw") + '"' : "") +
      ' alt="' + esc(opts.alt || "") + '" loading="lazy" decoding="async"' +
      (opts.w ? ' width="' + opts.w + '" height="' + opts.h + '"' : "") + ">";
  }

  /* ---------- Static bindings (hours, year, data-src-photo) ---------- */
  function bindStatic() {
    $$("[data-hours]").forEach(function (el) { el.textContent = SITE.hours; });
    $$("[data-hours-note]").forEach(function (el) { el.textContent = SITE.hoursNote; });
    $$("[data-year]").forEach(function (el) { el.textContent = new Date().getFullYear(); });
    $$("[data-directions]").forEach(function (el) { el.href = SITE.directions; });
    $$("img[data-src-photo]").forEach(function (el) {
      var id = PHOTO[el.getAttribute("data-src-photo")];
      var w = +el.getAttribute("data-w") || 1200;
      var h = +el.getAttribute("data-h") || 0;
      var ratio = h ? h / w : 0;
      el.src = img(id, w, h);
      if (id && id.indexOf("photo-") === 0) {
        el.srcset = srcset(id, [Math.round(w / 2), w, Math.round(w * 1.5)], ratio);
        el.sizes = el.closest(".restaurant") ? "100vw" : "(max-width: 900px) 100vw, 50vw";
      }
    });
  }

  /* ---------- Header : état scrollé + masquage au scroll ---------- */
  function initHeader() {
    var header = $(".site-header");
    var lastY = window.scrollY;
    var ticking = false;
    function update() {
      var y = window.scrollY;
      header.classList.toggle("is-scrolled", y > 40);
      var menuOpen = document.body.classList.contains("is-locked");
      header.classList.toggle("is-hidden", !menuOpen && y > 600 && y > lastY + 4);
      if (y < lastY - 4 || y < 600) header.classList.remove("is-hidden");
      if (y < window.innerHeight * 0.6) links.forEach(function (l) { l.classList.remove("is-active"); l.removeAttribute("aria-current"); });
      lastY = y;
      ticking = false;
    }
    var links = $$(".nav__link");
    window.addEventListener("scroll", function () {
      if (!ticking) { requestAnimationFrame(update); ticking = true; }
    }, { passive: true });
    update();

    // Lien actif selon la section visible
    var map = {};
    links.forEach(function (l) { map[l.getAttribute("href").slice(1)] = l; });
    var io = new IntersectionObserver(function (entries) {
      entries.forEach(function (e) {
        if (e.isIntersecting && map[e.target.id]) {
          links.forEach(function (l) { l.classList.remove("is-active"); l.removeAttribute("aria-current"); });
          map[e.target.id].classList.add("is-active");
          map[e.target.id].setAttribute("aria-current", "true");
        }
      });
    }, { rootMargin: "-45% 0px -50% 0px" });
    Object.keys(map).forEach(function (id) { var s = document.getElementById(id); if (s) io.observe(s); });
  }

  /* ---------- Mobile menu ---------- */
  function initMobileMenu() {
    var btn = $(".burger");
    var panel = $("#mobile-menu");
    if (!btn || !panel) return;
    panel.removeAttribute("hidden");
    panel.setAttribute("aria-hidden", "true");
    panel.inert = true;

    function setOpen(open) {
      btn.setAttribute("aria-expanded", String(open));
      btn.setAttribute("aria-label", open ? "Close menu" : "Open menu");
      panel.classList.toggle("is-open", open);
      panel.setAttribute("aria-hidden", String(!open));
      panel.inert = !open;
      document.body.classList.toggle("is-locked", open);
      if (open) { var first = $("a", panel); if (first) setTimeout(function () { first.focus(); }, 300); }
    }
    btn.addEventListener("click", function () { setOpen(btn.getAttribute("aria-expanded") !== "true"); });
    $$("a", panel).forEach(function (a) { a.addEventListener("click", function () { setOpen(false); }); });
    document.addEventListener("keydown", function (e) {
      if (e.key === "Escape" && panel.classList.contains("is-open")) { setOpen(false); btn.focus(); }
    });
    window.matchMedia("(min-width: 901px)").addEventListener("change", function (m) { if (m.matches) setOpen(false); });
  }

  /* ---------- Menu interactif (tabs accessibles) ---------- */
  function cardHTML(item, i) {
    var tag = item.tag ? '<span class="card__tag">' + esc(item.tag) + "</span>" : "";
    var no = '<span class="card__no" aria-hidden="true">' + pad(i + 1) + "</span>";
    return '<article class="card" style="--i:' + i + '">' +
      '<div class="card__media">' + tag + no +
        picture(item.image, { widths: [400, 640, 960], ratio: 0.75, sizes: "(max-width: 600px) 40vw, (max-width: 1100px) 50vw, 33vw", alt: item.name, w: 640, h: 480 }) +
      "</div>" +
      '<div class="card__body">' +
        '<div class="card__top"><h4 class="card__name">' + esc(item.name) + "</h4>" + price(item.price) + "</div>" +
        '<p class="card__desc">' + item.desc.map(esc).join(" · ") + "</p>" +
      "</div></article>";
  }

  function initMenu() {
    var tabsEl = $("[data-menu-tabs]");
    var panelsEl = $("[data-menu-panels]");
    if (!tabsEl || !panelsEl) return;
    var indicator = $(".tabs__indicator", tabsEl);

    MENU.categories.forEach(function (cat, idx) {
      var tab = document.createElement("button");
      tab.className = "tab";
      tab.type = "button";
      tab.id = "tab-" + cat.id;
      tab.setAttribute("role", "tab");
      tab.setAttribute("aria-controls", "panel-" + cat.id);
      tab.setAttribute("aria-selected", idx === 0 ? "true" : "false");
      tab.tabIndex = idx === 0 ? 0 : -1;
      tab.innerHTML = esc(cat.label) + "<sup>" + cat.items.length + "</sup>";
      tabsEl.appendChild(tab);

      var panel = document.createElement("div");
      panel.className = "menu-panel";
      panel.id = "panel-" + cat.id;
      panel.setAttribute("role", "tabpanel");
      panel.setAttribute("aria-labelledby", tab.id);
      panel.tabIndex = 0;
      if (idx !== 0) panel.hidden = true;
      panel.innerHTML =
        '<h3 class="sr-only">' + esc(cat.label) + "</h3>" +
        (cat.intro ? '<p class="menu-panel__intro">' + esc(cat.intro) + "</p>" : "") +
        '<div class="menu-grid">' + (idx === 0 ? cat.items.map(cardHTML).join("") : "") + "</div>";
      panel._cat = cat;
      panel._rendered = idx === 0;
      panelsEl.appendChild(panel);
    });

    var tabs = $$(".tab", tabsEl);

    function moveIndicator(tab) {
      if (!indicator || !tab) return;
      indicator.style.width = tab.offsetWidth + "px";
      indicator.style.transform = "translateX(" + tab.offsetLeft + "px)";
    }

    function select(tab, focus) {
      tabs.forEach(function (t) {
        var on = t === tab;
        t.setAttribute("aria-selected", String(on));
        t.tabIndex = on ? 0 : -1;
        var p = document.getElementById(t.getAttribute("aria-controls"));
        if (on) {
          if (!p._rendered) { $(".menu-grid", p).innerHTML = p._cat.items.map(cardHTML).join(""); p._rendered = true; }
          else { $$(".card", p).forEach(function (c) { c.style.animation = "none"; c.offsetHeight; c.style.animation = ""; }); }
          p.hidden = false;
        } else { p.hidden = true; }
      });
      moveIndicator(tab);
      if (focus) tab.focus();
      tab.scrollIntoView({ block: "nearest", inline: "center", behavior: reduceMotion ? "auto" : "smooth" });
    }

    tabs.forEach(function (tab, i) {
      tab.addEventListener("click", function () { select(tab); });
      tab.addEventListener("keydown", function (e) {
        var n = null;
        if (e.key === "ArrowRight") n = tabs[(i + 1) % tabs.length];
        if (e.key === "ArrowLeft") n = tabs[(i - 1 + tabs.length) % tabs.length];
        if (e.key === "Home") n = tabs[0];
        if (e.key === "End") n = tabs[tabs.length - 1];
        if (n) { e.preventDefault(); select(n, true); }
      });
    });

    requestAnimationFrame(function () { moveIndicator(tabs[0]); });
    window.addEventListener("resize", function () {
      moveIndicator($('.tab[aria-selected="true"]', tabsEl));
    });
    if (document.fonts && document.fonts.ready) {
      document.fonts.ready.then(function () { moveIndicator($('.tab[aria-selected="true"]', tabsEl)); });
    }

    // Extras
    var extras = $("[data-extras]");
    if (extras) {
      extras.innerHTML = MENU.extras.map(function (x) {
        return "<li><span>" + esc(x.name) + '</span><span class="leader" aria-hidden="true"></span><span class="p">' +
          (x.price != null ? x.price : "—") + '<span class="sr-only"> ' + SITE.currency + "</span></span></li>";
      }).join("");
    }
  }

  /* ---------- Signature : slider animé (mot géant + burger + ingrédients) ---------- */

  // Ingrédients dessinés en SVG (viewBox 0 0 40 40), tons naturels désaturés
  var BITS = {
    sesame: '<ellipse cx="20" cy="20" rx="6.5" ry="11" fill="#efe2c6"/><ellipse cx="18" cy="16" rx="2" ry="4" fill="#fff8ea" opacity=".6"/>',
    pickle: '<circle cx="20" cy="20" r="17" fill="#5f6d2f"/><circle cx="20" cy="20" r="13.5" fill="#94a052"/><g fill="#d9d8a0"><circle cx="20" cy="13" r="1.6"/><circle cx="26" cy="20" r="1.6"/><circle cx="20" cy="27" r="1.6"/><circle cx="14" cy="20" r="1.6"/></g>',
    onion: '<circle cx="20" cy="20" r="16" fill="none" stroke="#efe4d2" stroke-width="3.2"/><circle cx="20" cy="20" r="10.5" fill="none" stroke="#d9c7e0" stroke-width="2.2" opacity=".85"/>',
    cheese: '<path d="M5 9 35 5 33 33 7 35Z" fill="#e3a63b"/><path d="M5 9 35 5 34 12 6 15Z" fill="#f0c26a" opacity=".7"/><circle cx="14" cy="24" r="2.5" fill="#c98a22"/><circle cx="25" cy="19" r="1.8" fill="#c98a22"/>',
    jalapeno: '<circle cx="20" cy="20" r="16" fill="#2f5a22"/><circle cx="20" cy="20" r="11.5" fill="#9cba5f"/><g fill="#f1ebc8"><circle cx="20" cy="15" r="2"/><circle cx="24.5" cy="22" r="2"/><circle cx="15.5" cy="22" r="2"/></g>',
    chili: '<path d="M8 22c4-10 14-14 24-12-3 3-4 7-9 11-5 4-11 4-15 1Z" fill="#b13420"/><path d="M30 10c2-2 3-4 3-6" stroke="#4f6b2a" stroke-width="2.5" fill="none" stroke-linecap="round"/>',
    mushroom: '<path d="M4 20C4 10 12 5 20 5s16 5 16 15Z" fill="#8a6a49"/><path d="M8 18c2-7 7-10 12-10" stroke="#b08c68" stroke-width="2" fill="none" stroke-linecap="round"/><path d="M14 20h12l-2 15h-8Z" fill="#e8dcc6"/>',
    leaf: '<path d="M6 34C6 18 16 6 34 5 33 22 22 33 6 34Z" fill="#4f6d2e"/><path d="M7 33 30 9" stroke="#8fae5a" stroke-width="1.6" fill="none"/>',
    bacon: '<path d="M3 14c6-6 10 4 17-2s11 4 17-2v12c-6 6-10-4-17 2S9 20 3 26Z" fill="#8a3526"/><path d="M3 19c6-6 10 4 17-2s11 4 17-2" stroke="#e4ac8c" stroke-width="2.6" fill="none"/>'
  };
  // Positions finales autour du burger : [x %, y %, taille px, rotation, flou]
  var BIT_POS = [
    [-36, -30, 60, -24, 0], [33, -36, 50, 32, 0], [41, 6, 72, -12, 0], [-43, 12, 66, 18, 0],
    [-22, 38, 42, 40, 1], [26, 35, 56, -36, 0], [6, -46, 34, 12, 1], [-6, 46, 38, -18, 0]
  ];

  function initSignature() {
    var root = $("[data-slider]");
    if (!root || !BB.SIGNATURE || !BB.SIGNATURE.length) return;

    // Associe chaque slide au produit réel du menu (prix + composition)
    var all = [];
    MENU.categories.forEach(function (c) { all = all.concat(c.items); });
    var slides = BB.SIGNATURE.map(function (s) {
      var it = all.filter(function (i) { return i.name === s.item; })[0];
      return it ? { s: s, it: it } : null;
    }).filter(Boolean);
    if (!slides.length) return;

    var bgEl = $("[data-slider-bg]", root), wordEl = $("[data-slider-word]", root),
        bitsEl = $("[data-slider-bits]", root), dishEl = $("[data-slider-dish]", root),
        infoEl = $("[data-slider-info]", root), idxEl = $("[data-slider-index]", root),
        progEl = $("[data-slider-progress]", root);
    $("[data-slider-total]", root).textContent = pad(slides.length);

    var current = -1, busy = false;
    var OUT_MS = reduceMotion ? 0 : 1000;

    // Précharge les images
    slides.forEach(function (x) { var im = new Image(); im.src = img(x.s.image, 900, 900); });

    function wordHTML(word) {
      var letters = word.toUpperCase().split("");
      return '<div class="word" style="--len:' + Math.max(letters.length, 3) + '">' + letters.map(function (ch, k) {
        return '<span class="l"><span style="--d:' + k + '">' + esc(ch) + "</span></span>";
      }).join("") + "</div>";
    }
    function bitsHTML(list) {
      // Positions en px, relatives à la scène (largeur/hauteur réelles)
      var w = bitsEl.clientWidth || 800, h = bitsEl.clientHeight || 500;
      var narrow = w < 600;
      return list.map(function (name, k) {
        var p = BIT_POS[k % BIT_POS.length];
        var px = Math.round(p[0] / 100 * w * (narrow ? 1.05 : 0.82)), py = Math.round(p[1] / 100 * h * (narrow ? 0.78 : 1));
        return '<span class="bit' + (p[4] ? " bit--blur" : "") + '" style="--x:' + px + 'px;--y:' + py + 'px;--s:' + p[2] + 'px;--r:' + p[3] + 'deg;--d:' + k + ';--f:' + (5 + (k % 3)) + 's;--o:' + (p[4] ? 0.75 : 1) + '">' +
          '<svg viewBox="0 0 40 40">' + (BITS[name] || "") + "</svg></span>";
      }).join("");
    }

    // Remplace l'ancien élément par le nouveau avec animation de sortie / entrée
    function swap(container, html, delayIn) {
      var old = $$(":scope > *", container);
      old.forEach(function (o) { o.classList.remove("is-in"); o.classList.add("is-out"); });
      setTimeout(function () { old.forEach(function (o) { o.remove(); }); }, OUT_MS);
      var tmp = document.createElement("div");
      tmp.innerHTML = html;
      var nodes = Array.prototype.slice.call(tmp.children);
      nodes.forEach(function (n) { container.appendChild(n); });
      // Double rAF : laisse le navigateur peindre l'état initial avant la transition
      requestAnimationFrame(function () { requestAnimationFrame(function () {
        setTimeout(function () { nodes.forEach(function (n) { n.classList.add("is-in"); }); }, delayIn || 0);
      }); });
      return nodes;
    }

    function go(i, dir) {
      if (busy || i === current) return;
      busy = true;
      dir = dir || 1;
      var n = slides.length;
      i = (i + n) % n;
      var x = slides[i], first = current === -1;
      root.style.setProperty("--dir", dir);

      // 1. Fond : balayage circulaire depuis le côté de la flèche
      var layer = document.createElement("div");
      layer.className = "slider__layer";
      layer.style.cssText = "--base:" + x.s.tone[0] + ";--glow:" + x.s.tone[1] + ";--cx:" + (dir > 0 ? "100%" : "0%");
      if (first) layer.classList.add("is-in");
      bgEl.appendChild(layer);
      requestAnimationFrame(function () { requestAnimationFrame(function () { layer.classList.add("is-in"); }); });
      setTimeout(function () {
        $$(".slider__layer", bgEl).slice(0, -1).forEach(function (l) { l.remove(); });
      }, reduceMotion ? 0 : 1200);

      // 2. Mot géant, 3. burger, 4. ingrédients
      swap(wordEl, wordHTML(x.s.word), first ? 0 : 220);
      swap(dishEl, '<div class="dish">' + picture(x.s.image, { widths: [500, 900, 1200], ratio: 1, sizes: "(max-width: 900px) 84vw, 44vw", alt: "" }) + "</div>", first ? 0 : 200);
      swap(bitsEl, bitsHTML(x.s.bits), first ? 0 : 200);

      // 5. Infos produit
      infoEl.classList.remove("is-in");
      setTimeout(function () {
        infoEl.innerHTML =
          '<div class="slider__name"><h3>' + esc(x.it.name) + "</h3><strong>" + x.it.price + "<small>" + SITE.currency + "</small></strong></div>" +
          '<p class="slider__desc">' + x.it.desc.map(esc).join(" · ") + "</p>" +
          '<a class="slider__link" href="#menu">See the full menu</a>';
        requestAnimationFrame(function () { infoEl.classList.add("is-in"); });
      }, first || reduceMotion ? 0 : 380);

      idxEl.textContent = pad(i + 1);
      progEl.style.width = ((i + 1) / n * 100) + "%";
      root.setAttribute("aria-label", "Signature burgers — " + (i + 1) + " of " + n);
      current = i;
      setTimeout(function () { busy = false; }, reduceMotion ? 0 : 900);
    }

    $("[data-slider-prev]", root).addEventListener("click", function () { go(current - 1, -1); });
    $("[data-slider-next]", root).addEventListener("click", function () { go(current + 1, 1); });
    root.addEventListener("keydown", function (e) {
      if (e.target.closest("a")) return;
      if (e.key === "ArrowRight") { e.preventDefault(); go(current + 1, 1); }
      if (e.key === "ArrowLeft") { e.preventDefault(); go(current - 1, -1); }
    });

    // Swipe tactile / souris
    var sx = null, sy = null;
    root.addEventListener("pointerdown", function (e) { if (e.target.closest("button, a")) return; sx = e.clientX; sy = e.clientY; });
    root.addEventListener("pointerup", function (e) {
      if (sx === null) return;
      var dx = e.clientX - sx, dy = e.clientY - sy;
      sx = null;
      if (Math.abs(dx) > 50 && Math.abs(dx) > Math.abs(dy)) go(current + (dx < 0 ? 1 : -1), dx < 0 ? 1 : -1);
    });
    root.addEventListener("pointercancel", function () { sx = null; });

    // Première slide : jouée à l'entrée dans l'écran
    if ("IntersectionObserver" in window && !reduceMotion) {
      var io = new IntersectionObserver(function (en) {
        if (en[0].isIntersecting) { io.disconnect(); go(0, 1); }
      }, { threshold: 0.25 });
      io.observe(root);
    } else { go(0, 1); }
  }

  /* ---------- Galerie Instagram ---------- */
  function initGallery() {
    var el = $("[data-gallery]");
    if (!el) return;
    var icon = '<svg viewBox="0 0 24 24" aria-hidden="true"><rect x="3" y="3" width="18" height="18" rx="5" fill="none" stroke="currentColor" stroke-width="1.5"/><circle cx="12" cy="12" r="4" fill="none" stroke="currentColor" stroke-width="1.5"/><circle cx="17.3" cy="6.7" r="1.1" fill="currentColor"/></svg>';
    el.innerHTML = GALLERY.map(function (g, i) {
      return '<li class="g-item reveal" style="transition-delay:' + (i % 4) * 80 + 'ms">' +
        '<a href="' + esc(g.href || SITE.instagram) + '" target="_blank" rel="noopener" aria-label="' + esc(g.alt) + ' — view on Instagram">' +
          picture(g.image, { widths: [360, 600, 900], ratio: g.w && g.h ? g.h / g.w : 1.25, sizes: "(max-width: 900px) 50vw, 25vw", alt: g.alt, w: g.w || 600, h: g.h || 750 }) +
          '<span class="g-item__over">' + icon + "</span>" +
        "</a></li>";
    }).join("");
  }

  /* ---------- Carte Google Maps (chargée à la demande / à l'approche) ---------- */
  function initMap() {
    var wrap = $("[data-map]");
    var btn = $("[data-map-load]");
    if (!wrap || !btn) return;
    var loaded = false;
    function load() {
      if (loaded) return;
      loaded = true;
      var f = document.createElement("iframe");
      f.src = SITE.mapsEmbed;
      f.title = "Map — Beef & Buns, Avenue Les Orangers, Sousse";
      f.loading = "lazy";
      f.referrerPolicy = "no-referrer-when-downgrade";
      f.allowFullscreen = true;
      wrap.appendChild(f);
      f.addEventListener("load", function () { btn.remove(); });
    }
    btn.addEventListener("click", load);
    if ("IntersectionObserver" in window) {
      var io = new IntersectionObserver(function (e) {
        if (e[0].isIntersecting) { load(); io.disconnect(); }
      }, { rootMargin: "300px 0px" });
      io.observe(wrap);
    }
  }

  /* ---------- Reveal au scroll ---------- */
  function initReveal() {
    var els = $$(".reveal");
    if (reduceMotion || !("IntersectionObserver" in window)) {
      els.forEach(function (e) { e.classList.add("is-in"); });
      return;
    }
    var io = new IntersectionObserver(function (entries) {
      entries.forEach(function (e) {
        if (e.isIntersecting) { e.target.classList.add("is-in"); io.unobserve(e.target); }
      });
    }, { rootMargin: "0px 0px -8% 0px", threshold: 0.08 });
    els.forEach(function (e) { io.observe(e); });
  }

  /* ---------- Parallaxe discrète ---------- */
  function initParallax() {
    if (reduceMotion) return;
    var targets = $$(".restaurant__media img");
    if (!targets.length) return;
    var ticking = false;
    function update() {
      var vh = window.innerHeight;
      targets.forEach(function (img) {
        var r = img.parentElement.getBoundingClientRect();
        if (r.bottom < 0 || r.top > vh) return;
        var p = (r.top + r.height / 2 - vh / 2) / (vh + r.height); // -0.5 → 0.5
        img.style.setProperty("--py", (-p * 14 - 7).toFixed(2) + "%");
      });
      ticking = false;
    }
    window.addEventListener("scroll", function () {
      if (!ticking) { requestAnimationFrame(update); ticking = true; }
    }, { passive: true });
    update();
  }

  /* ---------- Bouton retour en haut + progression ---------- */
  function initToTop() {
    var btn = $(".to-top");
    if (!btn) return;
    var ticking = false;
    function update() {
      var max = document.documentElement.scrollHeight - window.innerHeight;
      var p = max > 0 ? (window.scrollY / max) * 100 : 0;
      btn.style.setProperty("--progress", p.toFixed(1));
      btn.classList.toggle("is-visible", window.scrollY > window.innerHeight * 0.8);
      ticking = false;
    }
    window.addEventListener("scroll", function () {
      if (!ticking) { requestAnimationFrame(update); ticking = true; }
    }, { passive: true });
    btn.addEventListener("click", function (e) {
      e.preventDefault();
      window.scrollTo({ top: 0, behavior: reduceMotion ? "auto" : "smooth" });
      var logo = $(".logo"); if (logo) logo.focus({ preventScroll: true });
    });
    update();
  }

  /* ---------- Intro du hero ---------- */
  function initHero() {
    var hero = $(".hero__img");
    var go = function () { document.documentElement.classList.add("is-loaded"); };
    if (!hero || hero.complete) { requestAnimationFrame(go); }
    else {
      hero.addEventListener("load", go, { once: true });
      hero.addEventListener("error", go, { once: true });
      setTimeout(go, 1600); // garde-fou si l'image tarde
    }
  }

  /* ---------- Boot ---------- */
  bindStatic();
  initHero();
  initHeader();
  initMobileMenu();
  initMenu();
  initSignature();
  initGallery();
  initMap();
  initReveal();
  initParallax();
  initToTop();
})();
